export { FavoritesBar } from './favorites-bar';
