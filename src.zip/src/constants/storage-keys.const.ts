export const LS_KEY_HISTORY = 'weather__history';
export const LS_KEY_FAVORITES = 'weather__favorites';
export const HISTORY_LIMIT = 3;
