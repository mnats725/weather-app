export { fetchWeather } from './weather';
